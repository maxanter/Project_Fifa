# Mecze Fifa
# Aplikacja umożliwia dodawanie, oraz usuwanie meczy z tabeli.
# Aby móc korzystać z możliwości tabeli należy się zalogować
# W lewym górnym roku strony znajduje się przycisk, po jego naciśnięciu użytkownik zostanie przeniesiony na stronę logowania, gdzie będzie musiał się zalogować.
# Dostępne konto:
# login: root
# hasło root
# Po zalogowaniu się użytkownik zostanie przeniesiony na główną stronę gdzie znajduje się tabela.
# Dostępne możliwości:
#   Sortowanie tabeli
#   Usunięcie Meczu
#   Dodanie nowego meczu
# 
# Sortowanie:
# 1.Aby posortować tabele należy kliknąć w Select. 
# 2.Po kliknięciu pojawią się opcje sortowania tabeli.
# 3.Wybierz jedną z opcji i naciśnij 'Sortuj'.
#   Uwaga! jeżeli nie dodałeś uprzednio żadnych rekordów, sortowanie nie powiedzie się.
#
# Usunięcie Meczu:
# 1.Aby usunąć mecz naciśnij przycisk 'Usuń'.
# 2.Wybrany mecz zostanie usunięty z tabeli.
#   Uwaga! jeżeli nie dodałeś uprzednio żadnych rekordów, nie pojawi się przycisk 'Usuń'
#
# Dodawanie Meczy:
# 1.Aby dodać mecz, należy wypełnić arkusz, który znajduje się pod tabelą.
# 2.Po wypełnieniu arkusza, naciśnij przycisk 'Dodaj Mecz'
# 3.Nowy rekord pojawi się w tabeli

